// Scripts para otimização de conversão de vendas

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar FAQ accordion
    initFaqAccordion();
    
    // Inicializar contador regressivo
    initCountdown();
    
    // Inicializar animações de scroll
    initScrollAnimations();
    
    // Inicializar pop-up de saída
    initExitIntent();
    
    // Inicializar notificações de compras recentes
    initRecentPurchaseNotifications();
});

// Função para inicializar o accordion de FAQ
function initFaqAccordion() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    if (faqItems.length > 0) {
        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question');
            
            question.addEventListener('click', () => {
                // Verifica se o item atual está ativo
                const isActive = item.classList.contains('active');
                
                // Fecha todos os itens
                faqItems.forEach(faqItem => {
                    faqItem.classList.remove('active');
                });
                
                // Se o item clicado não estava ativo, abre-o
                if (!isActive) {
                    item.classList.add('active');
                }
            });
        });
        
        // Abre o primeiro item por padrão
        faqItems[0].classList.add('active');
    }
}

// Função para inicializar contador regressivo
function initCountdown() {
    const countdownElement = document.querySelector('.countdown-timer');
    
    if (countdownElement) {
        // Define a data final (24 horas a partir de agora)
        const now = new Date();
        const endTime = new Date(now.getTime() + 24 * 60 * 60 * 1000);
        
        // Atualiza o contador a cada segundo
        const countdownInterval = setInterval(updateCountdown, 1000);
        
        function updateCountdown() {
            const currentTime = new Date();
            const timeDifference = endTime - currentTime;
            
            // Se o tempo acabou, limpa o intervalo
            if (timeDifference <= 0) {
                clearInterval(countdownInterval);
                return;
            }
            
            // Calcula horas, minutos e segundos restantes
            const hours = Math.floor(timeDifference / (1000 * 60 * 60));
            const minutes = Math.floor((timeDifference % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((timeDifference % (1000 * 60)) / 1000);
            
            // Atualiza os elementos HTML
            document.getElementById('countdown-hours').textContent = hours.toString().padStart(2, '0');
            document.getElementById('countdown-minutes').textContent = minutes.toString().padStart(2, '0');
            document.getElementById('countdown-seconds').textContent = seconds.toString().padStart(2, '0');
        }
        
        // Chama a função imediatamente para evitar atraso na exibição
        updateCountdown();
    }
}

// Função para inicializar animações de scroll
function initScrollAnimations() {
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    
    if (animatedElements.length > 0) {
        // Função para verificar se um elemento está visível na viewport
        function isElementInViewport(el) {
            const rect = el.getBoundingClientRect();
            return (
                rect.top <= (window.innerHeight || document.documentElement.clientHeight) * 0.8 &&
                rect.bottom >= 0
            );
        }
        
        // Função para animar elementos visíveis
        function animateVisibleElements() {
            animatedElements.forEach(element => {
                if (isElementInViewport(element) && !element.classList.contains('animated')) {
                    element.classList.add('animated');
                }
            });
        }
        
        // Adiciona listener de scroll
        window.addEventListener('scroll', animateVisibleElements);
        
        // Verifica elementos visíveis no carregamento inicial
        animateVisibleElements();
    }
}

// Função para inicializar pop-up de saída
function initExitIntent() {
    const exitPopup = document.getElementById('exit-popup');
    const closePopup = document.getElementById('close-popup');
    
    if (exitPopup && closePopup) {
        let showOnce = false;
        
        // Detecta quando o mouse sai da janela (intenção de saída)
        document.addEventListener('mouseout', function(e) {
            // Se o mouse sair pela parte superior da janela e o popup ainda não foi mostrado
            if (!showOnce && e.clientY < 20) {
                exitPopup.classList.add('show');
                showOnce = true;
            }
        });
        
        // Fecha o popup quando o botão de fechar é clicado
        closePopup.addEventListener('click', function() {
            exitPopup.classList.remove('show');
        });
        
        // Também fecha o popup quando clicado fora dele
        exitPopup.addEventListener('click', function(e) {
            if (e.target === exitPopup) {
                exitPopup.classList.remove('show');
            }
        });
    }
}

// Função para inicializar notificações de compras recentes
function initRecentPurchaseNotifications() {
    const notificationContainer = document.querySelector('.recent-purchase-notification');
    
    if (notificationContainer) {
        // Lista de nomes e cidades fictícias para as notificações
        const purchaseData = [
            { name: 'Maria S.', city: 'São Paulo', time: '2 minutos' },
            { name: 'João P.', city: 'Rio de Janeiro', time: '5 minutos' },
            { name: 'Ana L.', city: 'Belo Horizonte', time: '8 minutos' },
            { name: 'Carlos M.', city: 'Curitiba', time: '12 minutos' },
            { name: 'Juliana R.', city: 'Salvador', time: '15 minutos' },
            { name: 'Roberto A.', city: 'Brasília', time: '20 minutos' },
            { name: 'Fernanda T.', city: 'Recife', time: '25 minutos' },
            { name: 'Marcelo D.', city: 'Porto Alegre', time: '30 minutos' }
        ];
        
        let currentIndex = 0;
        
        // Função para mostrar uma notificação
        function showNotification() {
            const purchase = purchaseData[currentIndex];
            
            // Atualiza o conteúdo da notificação
            notificationContainer.innerHTML = `
                <div class="notification-content">
                    <i class="fas fa-shopping-cart"></i>
                    <div class="notification-text">
                        <p><strong>${purchase.name}</strong> de ${purchase.city}</p>
                        <p>comprou este e-book há ${purchase.time} atrás</p>
                    </div>
                </div>
                <button class="notification-close"><i class="fas fa-times"></i></button>
            `;
            
            // Mostra a notificação
            notificationContainer.classList.add('show');
            
            // Configura o botão de fechar
            const closeButton = notificationContainer.querySelector('.notification-close');
            if (closeButton) {
                closeButton.addEventListener('click', function() {
                    notificationContainer.classList.remove('show');
                });
            }
            
            // Esconde a notificação após 5 segundos
            setTimeout(() => {
                notificationContainer.classList.remove('show');
                
                // Prepara a próxima notificação
                currentIndex = (currentIndex + 1) % purchaseData.length;
                
                // Agenda a próxima notificação após um intervalo aleatório entre 30s e 2min
                const nextInterval = Math.floor(Math.random() * (120000 - 30000 + 1)) + 30000;
                setTimeout(showNotification, nextInterval);
            }, 5000);
        }
        
        // Inicia o ciclo de notificações após 15 segundos
        setTimeout(showNotification, 15000);
    }
}

// Função para destacar elementos de urgência
function pulseUrgencyElements() {
    const urgencyElements = document.querySelectorAll('.urgency-element');
    
    if (urgencyElements.length > 0) {
        urgencyElements.forEach(element => {
            // Adiciona classe para iniciar animação
            element.classList.add('pulse');
            
            // Remove a classe após a animação para permitir repetição
            setTimeout(() => {
                element.classList.remove('pulse');
            }, 2000);
        });
    }
}

// Repete a animação de urgência a cada 5 segundos
setInterval(pulseUrgencyElements, 5000);

// Função para mostrar número de vagas limitadas
function updateLimitedSpots() {
    const spotsElement = document.querySelector('.limited-spots');
    
    if (spotsElement) {
        // Número inicial de vagas (fictício)
        let spots = parseInt(localStorage.getItem('remainingSpots')) || 37;
        
        // Atualiza o elemento com o número atual
        spotsElement.textContent = spots;
        
        // Diminui aleatoriamente o número de vagas
        function decreaseSpots() {
            // 30% de chance de diminuir uma vaga
            if (Math.random() < 0.3 && spots > 5) {
                spots--;
                spotsElement.textContent = spots;
                localStorage.setItem('remainingSpots', spots);
                
                // Adiciona classe para destacar a mudança
                spotsElement.classList.add('highlight');
                setTimeout(() => {
                    spotsElement.classList.remove('highlight');
                }, 1000);
            }
        }
        
        // Verifica a cada 30-60 segundos
        setInterval(decreaseSpots, Math.floor(Math.random() * (60000 - 30000 + 1)) + 30000);
    }
}
