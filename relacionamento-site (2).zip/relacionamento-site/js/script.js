// Menu Toggle Functionality
document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.querySelector('.menu-toggle');
    const nav = document.querySelector('nav');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            nav.classList.add('active');
            
            // Create close button if it doesn't exist
            if (!document.querySelector('.close-menu')) {
                const closeBtn = document.createElement('div');
                closeBtn.className = 'close-menu';
                closeBtn.innerHTML = '<i class="fas fa-times"></i>';
                nav.appendChild(closeBtn);
                
                closeBtn.addEventListener('click', function() {
                    nav.classList.remove('active');
                });
            }
        });
    }
    
    // FAQ Accordion
    const faqItems = document.querySelectorAll('.faq-item');
    
    if (faqItems.length > 0) {
        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question');
            const answer = item.querySelector('.faq-answer');
            
            // Initially hide all answers except the first one
            if (item !== faqItems[0]) {
                answer.style.display = 'none';
            } else {
                item.classList.add('active');
            }
            
            question.addEventListener('click', function() {
                const isActive = item.classList.contains('active');
                
                // Close all items
                faqItems.forEach(faqItem => {
                    faqItem.classList.remove('active');
                    faqItem.querySelector('.faq-answer').style.display = 'none';
                });
                
                // If clicked item wasn't active, open it
                if (!isActive) {
                    item.classList.add('active');
                    answer.style.display = 'block';
                }
            });
        });
    }
    
    // Cart Functionality
    const cartPage = document.querySelector('.cart');
    if (cartPage) {
        // Quantity buttons
        const minusButtons = document.querySelectorAll('.quantity-btn.minus');
        const plusButtons = document.querySelectorAll('.quantity-btn.plus');
        const removeButtons = document.querySelectorAll('.remove-btn');
        const quantityInputs = document.querySelectorAll('.item-quantity input');
        const paymentOptions = document.querySelectorAll('input[name="payment"]');
        
        // Update cart totals
        function updateCartTotals() {
            const cartItems = document.querySelectorAll('.cart-item');
            let subtotal = 0;
            
            cartItems.forEach(item => {
                const price = parseFloat(item.querySelector('.item-price p').textContent.replace('R$', '').replace(',', '.'));
                const quantity = parseInt(item.querySelector('.item-quantity input').value);
                const total = price * quantity;
                
                item.querySelector('.item-total p').textContent = `R$${total.toFixed(2).replace('.', ',')}`;
                subtotal += total;
            });
            
            document.querySelector('.summary-item:first-child p:last-child').textContent = `R$${subtotal.toFixed(2).replace('.', ',')}`;
            
            // Check selected payment method for discount
            const selectedPayment = document.querySelector('input[name="payment"]:checked').value;
            let discount = 0;
            
            if (selectedPayment === 'pix') {
                discount = subtotal * 0.15; // 15% discount for PIX
            }
            
            document.querySelector('.summary-item:nth-child(2) p:last-child').textContent = `R$${discount.toFixed(2).replace('.', ',')}`;
            
            const total = subtotal - discount;
            document.querySelector('.summary-total p:last-child').textContent = `R$${total.toFixed(2).replace('.', ',')}`;
        }
        
        // Quantity minus button
        if (minusButtons.length > 0) {
            minusButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const input = this.nextElementSibling;
                    let value = parseInt(input.value);
                    
                    if (value > 1) {
                        value--;
                        input.value = value;
                        updateCartTotals();
                    }
                });
            });
        }
        
        // Quantity plus button
        if (plusButtons.length > 0) {
            plusButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const input = this.previousElementSibling;
                    let value = parseInt(input.value);
                    const max = parseInt(input.getAttribute('max'));
                    
                    if (value < max) {
                        value++;
                        input.value = value;
                        updateCartTotals();
                    }
                });
            });
        }
        
        // Quantity input change
        if (quantityInputs.length > 0) {
            quantityInputs.forEach(input => {
                input.addEventListener('change', function() {
                    let value = parseInt(this.value);
                    const min = parseInt(this.getAttribute('min'));
                    const max = parseInt(this.getAttribute('max'));
                    
                    if (value < min) {
                        this.value = min;
                    } else if (value > max) {
                        this.value = max;
                    }
                    
                    updateCartTotals();
                });
            });
        }
        
        // Remove item button
        if (removeButtons.length > 0) {
            removeButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const cartItem = this.closest('.cart-item');
                    cartItem.remove();
                    
                    // Check if cart is empty
                    const remainingItems = document.querySelectorAll('.cart-item');
                    if (remainingItems.length === 0) {
                        document.querySelector('.cart-empty').style.display = 'flex';
                    }
                    
                    updateCartTotals();
                });
            });
        }
        
        // Payment option change
        if (paymentOptions.length > 0) {
            paymentOptions.forEach(option => {
                option.addEventListener('change', function() {
                    updateCartTotals();
                });
            });
        }
        
        // Initialize cart totals
        updateCartTotals();
    }
    
    // Product page - Add to cart button
    const addToCartBtn = document.querySelector('.add-to-cart');
    if (addToCartBtn) {
        addToCartBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.className = 'success-message';
            successMessage.innerHTML = '<i class="fas fa-check-circle"></i> Produto adicionado ao carrinho!';
            
            document.body.appendChild(successMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                successMessage.classList.add('fade-out');
                setTimeout(() => {
                    successMessage.remove();
                }, 500);
            }, 3000);
        });
    }
    
    // Contact form validation
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Simple validation
            let isValid = true;
            const requiredFields = contactForm.querySelectorAll('[required]');
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('error');
                } else {
                    field.classList.remove('error');
                }
            });
            
            // Email validation
            const emailField = contactForm.querySelector('input[type="email"]');
            if (emailField && emailField.value.trim()) {
                const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailPattern.test(emailField.value)) {
                    isValid = false;
                    emailField.classList.add('error');
                }
            }
            
            if (isValid) {
                // Show success message
                const formContainer = contactForm.closest('.form-container');
                formContainer.innerHTML = `
                    <div class="form-success">
                        <i class="fas fa-check-circle"></i>
                        <h2>Mensagem Enviada com Sucesso!</h2>
                        <p>Agradecemos seu contato. Nossa equipe responderá em breve.</p>
                    </div>
                `;
            }
        });
    }
    
    // Checkout button
    const checkoutBtn = document.querySelector('.checkout-btn');
    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Show checkout success message (in a real site, this would redirect to payment processing)
            const cartContainer = document.querySelector('.cart-container');
            cartContainer.innerHTML = `
                <div class="checkout-success">
                    <i class="fas fa-check-circle"></i>
                    <h2>Pedido Realizado com Sucesso!</h2>
                    <p>Seu pedido foi processado e você receberá um e-mail com os detalhes da compra e instruções para download.</p>
                    <a href="index.html" class="btn-primary">Voltar para a Página Inicial</a>
                </div>
            `;
        });
    }
});
