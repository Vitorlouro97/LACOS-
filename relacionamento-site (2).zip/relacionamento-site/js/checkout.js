// Checkout functionality for e-commerce
document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const paymentOptions = document.querySelectorAll('input[name="payment"]');
    const checkoutBtn = document.querySelector('.checkout-btn');
    const cartItems = document.querySelectorAll('.cart-item');
    const summarySubtotal = document.querySelector('.summary-item:first-child p:last-child');
    const summaryDiscount = document.querySelector('.summary-item:nth-child(2) p:last-child');
    const summaryTotal = document.querySelector('.summary-total p:last-child');
    const pixPrice = document.querySelector('label[for="pix"] .payment-price');
    const creditPrice = document.querySelector('label[for="credit-card"] .payment-price');
    const boletoPrice = document.querySelector('label[for="boleto"] .payment-price');
    
    // Constants
    const PRODUCT_PRICE = 26.90;
    const PIX_DISCOUNT = 0.15; // 15% discount
    
    // Initialize cart
    function initializeCart() {
        if (cartItems.length > 0) {
            updateCartTotals();
        }
    }
    
    // Update cart totals based on selected payment method
    function updateCartTotals() {
        const selectedPayment = document.querySelector('input[name="payment"]:checked').value;
        let subtotal = PRODUCT_PRICE;
        let discount = 0;
        
        // Apply discount if PIX is selected
        if (selectedPayment === 'pix') {
            discount = subtotal * PIX_DISCOUNT;
        }
        
        const total = subtotal - discount;
        
        // Update display
        summarySubtotal.textContent = `R$${subtotal.toFixed(2).replace('.', ',')}`;
        summaryDiscount.textContent = `R$${discount.toFixed(2).replace('.', ',')}`;
        summaryTotal.textContent = `R$${total.toFixed(2).replace('.', ',')}`;
        
        // Update payment option prices
        pixPrice.textContent = `R$${(PRODUCT_PRICE * (1 - PIX_DISCOUNT)).toFixed(2).replace('.', ',')}`;
        creditPrice.textContent = `R$${PRODUCT_PRICE.toFixed(2).replace('.', ',')}`;
        boletoPrice.textContent = `R$${PRODUCT_PRICE.toFixed(2).replace('.', ',')}`;
    }
    
    // Handle payment method change
    if (paymentOptions.length > 0) {
        paymentOptions.forEach(option => {
            option.addEventListener('change', updateCartTotals);
        });
    }
    
    // Handle checkout process
    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            const selectedPayment = document.querySelector('input[name="payment"]:checked').value;
            const cartContainer = document.querySelector('.cart-container');
            
            // In a real implementation, this would connect to a payment gateway
            // For now, we'll simulate the checkout process
            
            // Show loading state
            checkoutBtn.textContent = 'Processando...';
            checkoutBtn.disabled = true;
            
            // Simulate processing time
            setTimeout(() => {
                // Show success message based on payment method
                let successMessage = '';
                
                switch(selectedPayment) {
                    case 'pix':
                        successMessage = `
                            <div class="checkout-success">
                                <i class="fas fa-check-circle"></i>
                                <h2>Pagamento via PIX selecionado!</h2>
                                <div class="pix-container">
                                    <p>Escaneie o QR Code abaixo ou copie a chave PIX:</p>
                                    <div class="pix-qrcode">
                                        <img src="images/qrcode-pix.png" alt="QR Code PIX">
                                    </div>
                                    <div class="pix-key">
                                        <p>Chave PIX: renovandolacos@exemplo.com.br</p>
                                        <button class="btn-secondary copy-btn">Copiar Chave</button>
                                    </div>
                                    <p class="pix-instructions">Após realizar o pagamento de <strong>R$22,86</strong>, você receberá o e-book em seu email em até 5 minutos.</p>
                                </div>
                                <p>Dúvidas? Entre em contato: <a href="mailto:contato@renovandolacos.com.br">contato@renovandolacos.com.br</a></p>
                            </div>
                        `;
                        break;
                    case 'credit-card':
                        successMessage = `
                            <div class="checkout-success">
                                <i class="fas fa-check-circle"></i>
                                <h2>Pagamento com Cartão</h2>
                                <form id="credit-card-form" class="payment-form">
                                    <div class="form-group">
                                        <label for="card-name">Nome no Cartão</label>
                                        <input type="text" id="card-name" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="card-number">Número do Cartão</label>
                                        <input type="text" id="card-number" placeholder="0000 0000 0000 0000" required>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group half">
                                            <label for="card-expiry">Validade (MM/AA)</label>
                                            <input type="text" id="card-expiry" placeholder="MM/AA" required>
                                        </div>
                                        <div class="form-group half">
                                            <label for="card-cvv">CVV</label>
                                            <input type="text" id="card-cvv" placeholder="123" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="card-installments">Parcelas</label>
                                        <select id="card-installments" required>
                                            <option value="1">1x de R$26,90 (sem juros)</option>
                                            <option value="2">2x de R$13,45 (sem juros)</option>
                                            <option value="3">3x de R$8,97 (sem juros)</option>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn-primary">Finalizar Pagamento</button>
                                </form>
                                <p>Pagamento 100% seguro. Seus dados são criptografados.</p>
                            </div>
                        `;
                        break;
                    case 'boleto':
                        successMessage = `
                            <div class="checkout-success">
                                <i class="fas fa-check-circle"></i>
                                <h2>Boleto Bancário Gerado!</h2>
                                <div class="boleto-container">
                                    <p>Seu boleto foi gerado com sucesso no valor de <strong>R$26,90</strong>.</p>
                                    <div class="boleto-actions">
                                        <a href="#" class="btn-primary download-boleto">Baixar Boleto</a>
                                        <a href="#" class="btn-secondary email-boleto">Enviar por Email</a>
                                    </div>
                                    <p class="boleto-instructions">O boleto vence em 3 dias úteis. Após o pagamento, o e-book será enviado para seu email em até 24 horas úteis.</p>
                                    <div class="boleto-barcode">
                                        <img src="images/barcode.png" alt="Código de Barras do Boleto">
                                        <p class="boleto-code">34191.79001 01043.510047 91020.150008 9 87650000002690</p>
                                    </div>
                                </div>
                                <p>Dúvidas? Entre em contato: <a href="mailto:contato@renovandolacos.com.br">contato@renovandolacos.com.br</a></p>
                            </div>
                        `;
                        break;
                }
                
                // Update the cart container with success message
                cartContainer.innerHTML = successMessage;
                
                // Add event listeners for the new elements
                if (selectedPayment === 'pix') {
                    const copyBtn = document.querySelector('.copy-btn');
                    if (copyBtn) {
                        copyBtn.addEventListener('click', function() {
                            navigator.clipboard.writeText('renovandolacos@exemplo.com.br');
                            this.textContent = 'Copiado!';
                            setTimeout(() => {
                                this.textContent = 'Copiar Chave';
                            }, 2000);
                        });
                    }
                } else if (selectedPayment === 'credit-card') {
                    const cardForm = document.getElementById('credit-card-form');
                    if (cardForm) {
                        cardForm.addEventListener('submit', function(e) {
                            e.preventDefault();
                            cartContainer.innerHTML = `
                                <div class="checkout-success">
                                    <i class="fas fa-check-circle"></i>
                                    <h2>Pagamento Aprovado!</h2>
                                    <p>Seu pedido foi processado com sucesso. O e-book "Caminhos para a Reconciliação" será enviado para seu email em instantes.</p>
                                    <p>Número do pedido: #${Math.floor(100000 + Math.random() * 900000)}</p>
                                    <a href="index.html" class="btn-primary">Voltar para a Página Inicial</a>
                                </div>
                            `;
                        });
                    }
                } else if (selectedPayment === 'boleto') {
                    const downloadBtn = document.querySelector('.download-boleto');
                    const emailBtn = document.querySelector('.email-boleto');
                    
                    if (downloadBtn) {
                        downloadBtn.addEventListener('click', function(e) {
                            e.preventDefault();
                            alert('Em um site real, o boleto seria baixado como PDF.');
                        });
                    }
                    
                    if (emailBtn) {
                        emailBtn.addEventListener('click', function(e) {
                            e.preventDefault();
                            const email = prompt('Digite seu email para receber o boleto:');
                            if (email) {
                                alert(`Em um site real, o boleto seria enviado para ${email}`);
                            }
                        });
                    }
                }
            }, 1500);
        });
    }
    
    // Initialize
    initializeCart();
    
    // Add to cart functionality for product page
    const addToCartBtn = document.querySelector('.add-to-cart');
    if (addToCartBtn) {
        addToCartBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.className = 'success-message';
            successMessage.innerHTML = '<i class="fas fa-check-circle"></i> Produto adicionado ao carrinho!';
            
            document.body.appendChild(successMessage);
            
            // Remove message after 3 seconds
            setTimeout(() => {
                successMessage.classList.add('fade-out');
                setTimeout(() => {
                    successMessage.remove();
                }, 500);
            }, 3000);
            
            // Redirect to cart page after a delay
            setTimeout(() => {
                window.location.href = 'carrinho.html';
            }, 1000);
        });
    }
});
