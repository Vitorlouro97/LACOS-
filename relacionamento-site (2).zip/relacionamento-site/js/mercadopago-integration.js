// Integração com Mercado Pago
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se estamos na página de checkout
    if (document.querySelector('.checkout-form')) {
        setupMercadoPagoIntegration();
    }
});

function setupMercadoPagoIntegration() {
    // Carregar o SDK do Mercado Pago
    const script = document.createElement('script');
    script.src = "https://sdk.mercadopago.com/js/v2";
    script.onload = initMercadoPago;
    document.body.appendChild(script);
}

function initMercadoPago() {
    // Inicializar o Mercado Pago com a chave pública (substituir pela chave real em produção)
    const mp = new MercadoPago('TEST-a1234567-1234-1234-1234-123456789012', {
        locale: 'pt-BR'
    });

    // Configurar os diferentes métodos de pagamento
    setupPaymentMethods(mp);
    
    // Configurar o formulário de checkout
    setupCheckoutForm(mp);
}

function setupPaymentMethods(mp) {
    // Obter elementos do formulário
    const paymentMethodPix = document.getElementById('pix');
    const paymentMethodCard = document.getElementById('credit-card');
    const paymentMethodBoleto = document.getElementById('boleto');
    
    if (!paymentMethodPix || !paymentMethodCard || !paymentMethodBoleto) return;
    
    // Adicionar listeners para mudança no método de pagamento
    [paymentMethodPix, paymentMethodCard, paymentMethodBoleto].forEach(method => {
        method.addEventListener('change', function() {
            // Esconder todos os formulários de pagamento
            document.querySelectorAll('.payment-form').forEach(form => {
                form.style.display = 'none';
            });
            
            // Mostrar o formulário correspondente ao método selecionado
            const selectedMethod = this.value;
            document.getElementById(`${selectedMethod}-form`).style.display = 'block';
            
            // Atualizar o preço baseado no método selecionado (15% de desconto para PIX)
            updatePrice(selectedMethod);
        });
    });
    
    // Iniciar com o método PIX selecionado por padrão
    if (paymentMethodPix.checked) {
        document.getElementById('pix-form').style.display = 'block';
        updatePrice('pix');
    }
}

function updatePrice(paymentMethod) {
    const originalPrice = 26.90;
    const discountRate = 0.15; // 15% de desconto para PIX
    
    const totalElement = document.querySelector('.checkout-total-value');
    if (!totalElement) return;
    
    if (paymentMethod === 'pix') {
        const discountedPrice = originalPrice * (1 - discountRate);
        totalElement.textContent = `R$${discountedPrice.toFixed(2)}`;
        
        // Atualizar o texto de desconto
        const discountElement = document.querySelector('.checkout-discount-value');
        if (discountElement) {
            const discountAmount = originalPrice * discountRate;
            discountElement.textContent = `R$${discountAmount.toFixed(2)}`;
        }
    } else {
        totalElement.textContent = `R$${originalPrice.toFixed(2)}`;
        
        // Zerar o desconto para outros métodos
        const discountElement = document.querySelector('.checkout-discount-value');
        if (discountElement) {
            discountElement.textContent = 'R$0,00';
        }
    }
}

function setupCheckoutForm(mp) {
    const form = document.querySelector('.checkout-form');
    if (!form) return;
    
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        
        // Validar o formulário
        if (!validateForm()) {
            return;
        }
        
        // Obter o método de pagamento selecionado
        const paymentMethod = document.querySelector('input[name="payment"]:checked').value;
        
        // Processar o pagamento de acordo com o método selecionado
        switch (paymentMethod) {
            case 'pix':
                processPix();
                break;
            case 'credit-card':
                processCreditCard(mp);
                break;
            case 'boleto':
                processBoleto();
                break;
        }
    });
}

function validateForm() {
    const name = document.getElementById('customer-name');
    const email = document.getElementById('customer-email');
    
    if (!name || !email) return false;
    
    let isValid = true;
    
    if (!name.value.trim()) {
        showError(name, 'Por favor, informe seu nome completo');
        isValid = false;
    } else {
        hideError(name);
    }
    
    if (!email.value.trim() || !isValidEmail(email.value)) {
        showError(email, 'Por favor, informe um e-mail válido');
        isValid = false;
    } else {
        hideError(email);
    }
    
    return isValid;
}

function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function showError(element, message) {
    const errorElement = document.createElement('div');
    errorElement.className = 'error-message';
    errorElement.textContent = message;
    
    // Remover mensagens de erro anteriores
    const existingError = element.parentNode.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }
    
    element.parentNode.appendChild(errorElement);
    element.classList.add('error');
}

function hideError(element) {
    const existingError = element.parentNode.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }
    element.classList.remove('error');
}

function processPix() {
    // Em um cenário real, aqui faríamos uma requisição ao backend
    // para gerar um QR code PIX via API do Mercado Pago
    
    // Simulação para demonstração
    showPaymentConfirmation('pix', {
        qrCode: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAACgCAMAAAC8EZcfAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAABjUExURUdwTP///////////////////////////////////////////////////////////////////////////////////////////////////////////x6CxA0AAAAgdFJOUwAQMEBQYHCAn6+/z9/vIDBQYHCPn6+/z9/vECA0QFCHyUuDAAADFklEQVR4AezBgQAAAACAoP2pF6kCAAAAAAAAAABg9uBALttoGADgb23btm3btm3btm3btm3bqe3NpGnSbXfbpD3JvtxgksnMZN9/3xtA/n+QQAIJJJBAAgkkkMBEwFZAIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSOAUQOI5wHCQQAIJJJBAAgkkkEACCSSQQAIJJJBAAgkkkEACCSSQQAIJJJBAAgnEJwAeAQQSSOAUQMoD/iqBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJIIIEEEkgggQQSSCCBBBJI4P8BQJmgA92PU58AAAAASUVORK5CYII=',
        code: '00020126580014BR.GOV.BCB.PIX0136123e4567-e89b-12d3-a456-426655440000',
        expirationDate: '30 minutos'
    });
}

function processCreditCard(mp) {
    // Em um cenário real, aqui usaríamos o SDK do Mercado Pago
    // para tokenizar o cartão e enviar para processamento
    
    // Simulação para demonstração
    showPaymentConfirmation('credit-card');
}

function processBoleto() {
    // Em um cenário real, aqui faríamos uma requisição ao backend
    // para gerar um boleto via API do Mercado Pago
    
    // Simulação para demonstração
    showPaymentConfirmation('boleto', {
        barcode: '34191.79001 01043.510047 91020.150008 9 87770026000',
        expirationDate: '3 dias úteis'
    });
}

function showPaymentConfirmation(method, data = {}) {
    // Esconder o formulário de checkout
    const checkoutForm = document.querySelector('.checkout-form');
    if (checkoutForm) {
        checkoutForm.style.display = 'none';
    }
    
    // Criar e mostrar a confirmação de pagamento
    const confirmationDiv = document.createElement('div');
    confirmationDiv.className = 'payment-confirmation';
    
    let confirmationContent = '';
    
    switch (method) {
        case 'pix':
            confirmationContent = `
                <h2>Pagamento via PIX</h2>
                <p>Escaneie o QR Code abaixo ou copie o código PIX para realizar o pagamento:</p>
                <div class="qr-code-container">
                    <img src="${data.qrCode}" alt="QR Code PIX">
                </div>
                <div class="pix-code-container">
                    <p class="pix-code">${data.code}</p>
                    <button class="copy-button" onclick="copyToClipboard('${data.code}')">Copiar</button>
                </div>
                <p class="expiration-info">Este QR Code expira em ${data.expirationDate}</p>
                <p class="payment-instructions">Após o pagamento, você receberá o e-book por e-mail em até 5 minutos.</p>
            `;
            break;
            
        case 'credit-card':
            confirmationContent = `
                <h2>Pagamento Aprovado!</h2>
                <div class="success-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <p>Seu pagamento foi processado com sucesso.</p>
                <p>O e-book "Caminhos para a Reconciliação" será enviado para o seu e-mail em instantes.</p>
                <p>Obrigado por sua compra!</p>
            `;
            break;
            
        case 'boleto':
            confirmationContent = `
                <h2>Boleto Gerado</h2>
                <p>Utilize o código de barras abaixo para realizar o pagamento:</p>
                <div class="barcode-container">
                    <img src="images/barcode.png" alt="Código de Barras">
                    <p class="barcode-number">${data.barcode}</p>
                    <button class="copy-button" onclick="copyToClipboard('${data.barcode}')">Copiar</button>
                </div>
                <p class="expiration-info">Este boleto vence em ${data.expirationDate}</p>
                <p class="payment-instructions">Após o pagamento, você receberá o e-book por e-mail em até 24 horas úteis.</p>
                <a href="#" class="btn-primary download-boleto">Baixar Boleto</a>
            `;
            break;
    }
    
    confirmationContent += `
        <div class="back-to-home">
            <a href="index.html">Voltar para a página inicial</a>
        </div>
    `;
    
    confirmationDiv.innerHTML = confirmationContent;
    
    // Adicionar a confirmação à página
    const checkoutContainer = document.querySelector('.checkout-container');
    if (checkoutContainer) {
        checkoutContainer.appendChild(confirmationDiv);
    }
}

// Função auxiliar para copiar texto para a área de transferência
function copyToClipboard(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
    
    // Mostrar mensagem de sucesso
    alert('Código copiado para a área de transferência!');
}
